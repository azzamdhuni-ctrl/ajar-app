# AJAR Docs - Android APK Project

A native Android wrapper (WebView) for the AJAR Document Manager.
Everything runs OFFLINE: all JS libraries are bundled in `app/src/main/assets/lib/`,
and all quotations / invoices / delivery notes / customers / signatures are saved
on the phone via localStorage. No server, no account, no internet needed.

## How to build the APK (one-time setup, ~15 min)

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio -> "Open" -> select this `AJAR-APK-Project` folder.
3. Let it sync Gradle (it downloads dependencies automatically on first open).
4. Build the APK:
   - Menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   - When done, click "locate" to find `app-debug.apk`
5. Copy the APK to your phone and install it
   (allow "Install from unknown sources" when prompted).

## Optional: signed release APK
Build > Generate Signed Bundle / APK > APK > Create new keystore.
Use this if you plan to distribute or update the app.

## What works in the app
- Edit Draft -> Generate Quotation -> Invoice -> Delivery Note
- Document history, saved customers, business addresses
- Draw/upload a signature and stamp it on invoices & delivery notes
- Upload business logo (all file pickers wired up natively)
- PRINT button uses Android's system print dialog -> save as PDF or print
- All data persists on the device only. Uninstalling the app deletes the data.
